import React from 'react';
import { useTranslation } from 'react-i18next';
import { useLanguage } from '../contexts/LanguageContext';

function LanguageSelectorModal({ isOpen, onClose }) {
  const { t, i18n } = useTranslation();
  const { languages, loading, changeLanguage } = useLanguage();

  const handleLanguageChange = (languageCode) => {
    changeLanguage(languageCode);
    // Modal o'chmasligi uchun onClose() ni chaqirmayapmiz
  };

  if (!isOpen) return null;

  return (
    <div className="onboarding-overlay" onClick={onClose}>
      <div className="onboarding-container" onClick={(e) => e.stopPropagation()}>
        <div className="onboarding-content">

          {/* Header */}
          <div className="onboarding-header">
            <div className="onboarding-icon">
              <i className="fas fa-globe"></i>
            </div>
            <h1 className="onboarding-title">{t('select_language')}</h1>
            <p className="onboarding-subtitle">{t('choose_your_preferred_language')}</p>
          </div>

          {/* Language Selection */}
          <div className="language-selection">
            <div className="language-options">
              {loading ? (
                <div className="loading-state">
                  <div className="spinner"></div>
                  <p>{t('loading')}...</p>
                </div>
              ) : languages && languages.length > 0 ? (
                languages.map((language) => (
                  <button
                    key={language.id}
                    className={`language-option ${i18n.resolvedLanguage === language.code ? 'active' : ''}`}
                    onClick={() => handleLanguageChange(language.code)}
                  >
                    <span className="language-flag">{language.flag}</span>
                    <span className="language-name">{language.name}</span>
                    {i18n.resolvedLanguage === language.code && (
                      <i className="fas fa-check language-check"></i>
                    )}
                  </button>
                ))
              ) : (
                <div className="error-state">
                  <p>{t('no_languages_found')}</p>
                </div>
              )}
            </div>
          </div>

          {/* Help Text */}
          <div className="onboarding-help">
            <p>{t('language_can_be_changed_later')}</p>
          </div>

          {/* Close Button */}
          <div className="onboarding-actions">
            <button 
              className="onboarding-btn secondary"
              onClick={onClose}
            >
              {t('close')}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}

export default LanguageSelectorModal;
